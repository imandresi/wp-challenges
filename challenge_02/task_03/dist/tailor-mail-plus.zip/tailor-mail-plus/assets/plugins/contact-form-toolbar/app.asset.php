<?php return array('dependencies' => array('react', 'react-dom'), 'version' => '18b4708b45f6c1dc3532');
