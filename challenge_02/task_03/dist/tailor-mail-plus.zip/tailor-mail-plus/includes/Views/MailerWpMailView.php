<?php

namespace Imandresi\TailorMailPlus\Views;

use Imandresi\TailorMailPlus\Views\AbstractView;

class MailerWpMailView extends AbstractView {

	public static function settings_panel($settings): string {
		return '';
	}

}