<?php return array('dependencies' => array('react', 'react-dom'), 'version' => 'bac62fe36fa9f49386a1');
